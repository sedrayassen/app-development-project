import 'package:flutter/material.dart';
import 'package:app_development_project/constants/app_colors.dart'; // غيّري اسم الـ package إذا لزم

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedDestination = 0;
  final Set<String> _favoriteProducts = {};

  static const List<_Category> _categories = [
    _Category('All', Icons.grid_view_rounded, Color(0xFFEAE7FF)),
    _Category('Fashion', Icons.checkroom_rounded, Color(0xFFFFE9E2)),
    _Category('Electronics', Icons.headphones_rounded, Color(0xFFE2F2FF)),
    _Category('Home', Icons.chair_alt_rounded, Color(0xFFE4F4EA)),
    _Category('Beauty', Icons.spa_outlined, Color(0xFFFFE8F1)),
    _Category('Sports', Icons.sports_basketball_rounded, Color(0xFFFFF1D9)),
  ];

  static const List<_Product> _products = [
    _Product(
      name: 'Everyday Sneakers',
      price: '\$89.00',
      category: 'Fashion',
      icon: Icons.directions_run_rounded,
      background: Color(0xFFF0ECFF),
      accent: Color(0xFF8A7DEB),
      tag: 'BESTSELLER',
    ),
    _Product(
      name: 'Wireless Headphones',
      price: '\$129.00',
      category: 'Electronics',
      icon: Icons.headphones_rounded,
      background: Color(0xFFE8F4FF),
      accent: Color(0xFF5A9EDD),
      tag: 'NEW',
    ),
    _Product(
      name: 'Ceramic Table Lamp',
      price: '\$64.00',
      category: 'Home',
      icon: Icons.light_rounded,
      background: Color(0xFFFFF2DF),
      accent: Color(0xFFE6A94F),
    ),
    _Product(
      name: 'Daily Skincare Set',
      price: '\$48.00',
      category: 'Beauty',
      icon: Icons.spa_outlined,
      background: Color(0xFFFFEAF1),
      accent: Color(0xFFE47CA1),
      tag: 'POPULAR',
    ),
    _Product(
      name: 'Classic Wristwatch',
      price: '\$156.00',
      category: 'Fashion',
      icon: Icons.watch_outlined,
      background: Color(0xFFEAF3EF),
      accent: Color(0xFF6BA58A),
    ),
    _Product(
      name: 'Travel Backpack',
      price: '\$72.00',
      category: 'Fashion',
      icon: Icons.backpack_outlined,
      background: Color(0xFFFFEAE1),
      accent: Color(0xFFDA8766),
    ),
  ];

  void _toggleFavorite(_Product product) {
    setState(() {
      if (!_favoriteProducts.add(product.name)) {
        _favoriteProducts.remove(product.name);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackground,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        titleSpacing: 24,
        title: const Text(
          'Discover',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 23,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
        ),
        actions: [
          _AppBarAction(
            icon: Icons.search_rounded,
            label: 'Search',
            onPressed: () {},
          ),
          _AppBarAction(
            icon: Icons.notifications_none_rounded,
            label: 'Notifications',
            onPressed: () {},
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: _AppBarAction(
              icon: Icons.shopping_bag_outlined,
              label: 'Cart',
              badge: '2',
              onPressed: () {},
            ),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1100),
                child: LayoutBuilder(
                  builder: (context, contentConstraints) {
                    final width = contentConstraints.maxWidth;
                    final columns = width >= 900
                        ? 4
                        : width >= 620
                            ? 3
                            : 2;
                    const spacing = 16.0;
                    final cardWidth =
                        (width - spacing * (columns - 1)) / columns;
                    final cardHeight = cardWidth + 105;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _WelcomeCard(width: width),
                        const SizedBox(height: 28),
                        const _SectionHeading(
                          title: 'Shop by category',
                          trailing: 'See All',
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          height: 105,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: _categories.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(width: 14),
                            itemBuilder: (context, index) =>
                                _CategoryTile(category: _categories[index]),
                          ),
                        ),
                        const SizedBox(height: 30),
                        const _SectionHeading(
                          title: 'Popular Products',
                          trailing: 'See All',
                        ),
                        const SizedBox(height: 16),
                        GridView.builder(
                          itemCount: _products.length,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: columns,
                            crossAxisSpacing: spacing,
                            mainAxisSpacing: spacing,
                            mainAxisExtent: cardHeight,
                          ),
                          itemBuilder: (context, index) {
                            final product = _products[index];
                            return _ProductCard(
                              product: product,
                              isFavorite:
                                  _favoriteProducts.contains(product.name),
                              onFavoritePressed: () =>
                                  _toggleFavorite(product),
                            );
                          },
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedDestination,
        onDestinationSelected: (index) {
          setState(() => _selectedDestination = index);
        },
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFECE9FF),
        height: 72,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'Categories',
          ),
          NavigationDestination(
            icon: Icon(Icons.shopping_bag_outlined),
            selectedIcon: Icon(Icons.shopping_bag_rounded),
            label: 'Cart',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard({required this.width});

  final double width;

  @override
  Widget build(BuildContext context) {
    final compact = width < 380;

    return Container(
      padding: EdgeInsets.all(compact ? 18 : 22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.gradientStart, Color(0xFFF9F8FF)],
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'MONDAY, JUNE 10',
                  style: TextStyle(
                    color: AppColors.textGray,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Good morning, Alex',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: compact ? 19 : 22,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Find something you’ll love today.',
                  style: TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: compact ? 48 : 56,
            height: compact ? 48 : 56,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.8),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryShadow,
                  blurRadius: 16,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: const Icon(
              Icons.person_rounded,
              color: AppColors.primary,
              size: 28,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({
    required this.title,
    required this.trailing,
  });

  final String title;
  final String trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
            ),
          ),
        ),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: AppColors.primary,
            padding: const EdgeInsets.symmetric(horizontal: 6),
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: Text(
            trailing,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.category});

  final _Category category;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70,
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: category.background,
              borderRadius: BorderRadius.circular(21),
            ),
            child: Icon(category.icon, color: const Color(0xFF514A78), size: 27),
          ),
          const SizedBox(height: 8),
          Text(
            category.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({
    required this.product,
    required this.isFavorite,
    required this.onFavoritePressed,
  });

  final _Product product;
  final bool isFavorite;
  final VoidCallback onFavoritePressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF29244D).withValues(alpha: 0.055),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: product.background,
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Center(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withValues(alpha: 0.42),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Icon(
                            product.icon,
                            size: 48,
                            color: product.accent,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                if (product.tag != null)
                  Positioned(
                    left: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.92),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text(
                        product.tag!,
                        style: const TextStyle(
                          color: AppColors.primary,
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.35,
                        ),
                      ),
                    ),
                  ),
                Positioned(
                  right: 7,
                  top: 7,
                  child: Material(
                    color: Colors.white.withValues(alpha: 0.92),
                    shape: const CircleBorder(),
                    child: InkWell(
                      onTap: onFavoritePressed,
                      customBorder: const CircleBorder(),
                      child: Padding(
                        padding: const EdgeInsets.all(7),
                        child: Icon(
                          isFavorite
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                          size: 17,
                          color: isFavorite
                              ? const Color(0xFFE66F8D)
                              : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            product.category,
            style: const TextStyle(
              color: AppColors.textGray,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            product.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            product.price,
            style: const TextStyle(
              color: AppColors.primary,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _AppBarAction extends StatelessWidget {
  const _AppBarAction({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.badge,
  });

  final IconData icon;
  final String label;
  final String? badge;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: label,
      onPressed: onPressed,
      icon: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(icon, color: AppColors.textDark, size: 23),
          if (badge != null)
            Positioned(
              right: -7,
              top: -6,
              child: Container(
                padding: const EdgeInsets.all(3),
                constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  badge!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    height: 1.1,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Category {
  const _Category(this.name, this.icon, this.background);

  final String name;
  final IconData icon;
  final Color background;
}

class _Product {
  const _Product({
    required this.name,
    required this.price,
    required this.category,
    required this.icon,
    required this.background,
    required this.accent,
    this.tag,
  });

  final String name;
  final String price;
  final String category;
  final IconData icon;
  final Color background;
  final Color accent;
  final String? tag;
}